<?php
  require_once 'assets/php/dbcon.inc.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <link href="assets/img/logo.jpg" rel="icon">
  <title>Comments - GivingTuesday Lesotho</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  <style>
	.give{
		background-color: white; /* Green background */
		border: 2px solid black;
		color: black; /* White text */
		padding: 15px 32px; /* Padding */
		text-align: center; /* Center the text */
		text-decoration: none; /* Remove underline */
		display: inline-block; /* Inline-block display */
		font-size: 16px; /* Font size */
		margin: 4px 2px; /* Margin */
		cursor: pointer; /* Pointer cursor on hover */
		border-radius: 7px; /* Rounded corners */
		
	}
	
	.give:hover {
		background-color: black; /* black background on hover */
		color: #fff; /* white text on hover */
		border: 2px solid #fff; /* Green border on hover */
	}

	
	.myform{
		height: 100%;
		padding: 30px;
		box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
		border: 1px solid gold;
		padding: 20px;
		border-radius: 10px;
		margin: 0 auto;
	}
  </style>
  <!-- =======================================================
  *This is the about us page of Giving Tuesday Lesotho!
  ======================================================== -->
</head>

<body class="about-page">
	
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <img src="assets/img/logo.jpg" alt="">
        <h1 class="sitename">#GivingTuesdayLesotho</h1> <span></span>
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="index.html">Home</a></li>
          <li class="dropdown"><a href="about.html"><span>About</span></a></li>
          <li class="dropdown"><a href="events.php"><span>Events</span></a></li>
          <li class="dropdown"><a href="gallery.html"><span>Gallery</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <ul>
              <li><a href="gallery.html#photos">Photos</a></li>
              <li><a href="gallery.html#vid">Videos</a></li>
            </ul>
          </li>
          <li><a href="comments.php" class="active">Comments</a></li>
          <li><a href="donate.html">Donate</a></li>
          <li><a href="contact.html">Contact</a></li>
          <!-- <li><a href=""><i class="bi bi-person"></i></a></li> -->
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

    </div>
  </header>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title dark-background" style="background-image: url(assets/img/page-title-bg.jpg);">
      <div class="container position-relative">
        <h1>Comments</h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.html">Home</a></li>
            <li class="current">Comments</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- Partners Section -->
    <section id="Partners" class="testimonials section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Comments Section</h2>
        <p>
          On GivingTuesday, Lesotho stands as a beacon of hope and compassion, showcasing the power of community driven efforts.
          As we gather together to celebrate our shared commitment to giving back, we emphasize the importance of every contrinution, 
          no matter how small. This special day reminds us that together we can create lasting change and uplift those in need across 
          our nation. By sharing our experiences and encouraging one another, we strengthen the fabric of our society and foster a spirit of unity.
          Leave a Comment and join us in spreading kindness and generosity as we make a meaningful impact in the lives of many.
        </p>
      </div><!-- End Section Title -->

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="swiper init-swiper">
          <script type="application/json" class="swiper-config">
            {
              "loop": true,
              "speed": 600,
              "autoplay": {
                "delay": 5000
              },
              "slidesPerView": "auto",
              "pagination": {
                "el": ".swiper-pagination",
                "type": "bullets",
                "clickable": true
              },
              "breakpoints": {
                "320": {
                  "slidesPerView": 1,
                  "spaceBetween": 40
                },
                "1200": {
                  "slidesPerView": 2,
                  "spaceBetween": 20
                }
              }
            }
          </script>
            <div class="swiper-wrapper">
                <?php 
        
                  $sql = "SELECT FULLNAMES,DETAILS FROM comments;";
                  $result = mysqli_query($conn, $sql);
                  $resultCheck = mysqli_num_rows($result);

                  if($resultCheck > 0){
                      while($row = mysqli_fetch_array($result)){
                          echo '<div class="swiper-slide">';
                          echo '  <div class="testimonial-wrap">';
                          echo '    <div class="testimonial-item">';
                          echo '      <h3>' .$row['FULLNAMES']. '</h3>';
                          echo '      <div class="stars">';
                          echo '        <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>';
                          echo '      </div>';
                          echo '      <p>';
                          echo '        <i class="bi bi-quote quote-icon-left"></i>';
                          echo '        <span>' .$row['DETAILS']. '</span>';
                          echo '        <i class="bi bi-quote quote-icon-right"></i>';
                          echo '      </p>';
                          echo '    </div>';
                          echo '  </div>';
                          echo '</div><!-- End testimonial item -->';
                      }
                  }else {
                      echo " ".$conn -> error;
                  }                
              ?>
            </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>

    </section><!-- /Testimonials Section -->
	<!-- Contact Section -->
    <section id="contact" class="contact section">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

		<div class="container section-title" data-aos="fade-up">
			<h2>Leave a Comment</h2>
		</div>
        <div class="row gy-4 mt-1">
            <form action="assets/php/comment.inc.php" method="post" class="myform" data-aos="fade-up" data-aos-delay="400">
              <div class="row gy-4">

                <div class="col-md-6">
                  <input type="text" name="names" class="form-control" placeholder="Your Names" required="">
                </div>

                <div class="col-md-6 ">
                  <input type="email" class="form-control" name="email" placeholder="Your Email" required="">
                </div>

                <div class="col-md-12">
                  <textarea class="form-control" name="comment" rows="6" placeholder="Write Your Comment Here!" required=""></textarea>
                </div>

                <div class="col-md-12 text-center">
                  <button type="submit" name="Add" class="give">Submit</button>
                </div>

              </div>
            </form>
          </div><!-- End Contact Form -->

        </div>

      </div>

    </section><!-- /Contact Section -->


  </main>

  <footer id="footer" class="footer dark-background">

    <div class="container footer-top">
      <div class="row gy-4">
        <div class="col-lg-4 col-md-6 footer-about">
          <a href="index.html" class="logo d-flex align-items-center">
             <img src="assets/img/logo.png" alt="#GivingTuesday Lesotho" width="" height="400px">
          </a>
          <div class="footer-contact pt-3">
            <!-- <p>A108 Adam Street</p> -->
            <p>Matala, Phase 2, Maseru 100, Lesotho</p>
            <p class="mt-3"><strong>Phone:</strong><br> <span>(+266) 590 30 122 | 625 78 117</span></p>
            <p><strong>Email:</strong><br> <span>info@givingtuesdaylesotho.org.ls</span></p>
          </div>
          <div class="social-links d-flex mt-4">
            <!-- <a href=""><i class="bi bi-twitter-x"></i></a> -->
            <a href="https://www.facebook.com/profile.php?id=61564015867469"><i class="bi bi-facebook"></i></a>
            <a href="https://www.instagram.com/givingtuesdaylesotho?igsh=YzljYTk1ODg3Zg=="><i class="bi bi-instagram"></i></a>
            <a href="https://www.linkedin.com/company/giving-tuesday-lesotho/about/?viewAsMember=true"><i class="bi bi-linkedin"></i></a>
          </div>
        </div>

        <div class="col-lg-2 col-md-3 footer-links">
          <h4>Useful Links</h4>
          <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="donate.html">Donations</a></li>
            <li><a href="contact.html">Contact</a></li>
            <li><a href="privacy_policy.html">Privacy Policy</a></li>
            <!-- <li><a href="#">Terms of service</a></li> -->
          </ul>
        </div>
        
        <div class="col-lg-2 col-md-3 footer-links">
          <h4>About</h4>
          <ul>
            <li><a href="about.html#About">What is GivingTuesday ?</a></li>
            <li><a href="about.html#Team">Team members</a></li>
            <li><a href="about.html#Partners">Partners</a></li>            
            <li><a href="about.html#lead">Community Leaders</a></li>
          </ul>
        </div>

        <!-- <div class="col-lg-2 col-md-3 footer-links">
          <h4>Organizations</h4>
          <ul>
            <li><a href="Organizations.html#char">NGOs & Charities</a></li>
            <li><a href="Organizations.html#edu">Educational Facilities</a></li>
            <li><a href="Organizations.html#other">Other Institutions</a></li>
          </ul>
        </div> -->

        <div class="col-lg-2 col-md-3 footer-links">
          <h4>Gallery</h4>
          <ul>
            <li><a href="gallery.html#photos">Photo Gallery</a></li>
            <li><a href="gallery.html#vid">Video Gallery</a></li>
            <!-- <li><a href="#">Suscipit distinctio</a></li> -->
          </ul>
        </div>

      </div>
    </div>

    <div class="container copyright text-center mt-4">
      <p>© <span>Copyright</span> <strong class="px-1 sitename">GivingTuesday</strong> <span>All Rights Reserved</span></p>
      <div class="credits">
        Designed for: <a href="#">GivingTuesday Lesotho</a>
      </div>
    </div>

  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>


</html>