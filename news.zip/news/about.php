<?php
  require_once 'assets/php/dbcon.inc.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <link href="assets/img/logo.jpg" rel="icon">
  <title>About - GivingTuesday Lesotho</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
<style>
	.justified {
            text-align: justify;
        }
  .testimonial-item h3{
    text-indent: 50px;
  }
  .testimonial-item .stars #fst{
    text-indent: 48px;
  }
  .testimonial-item p{
    text-indent: 18px;
  }
</style>
  <!-- =======================================================
  *This is the about us page of Giving Tuesday Lesotho!
  ======================================================== -->
</head>

<body class="about-page">

  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <img src="assets/img/logo.jpg" alt="">
        <h1 class="sitename">#GivingTuesdayLesotho</h1> <span></span>
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="index.html">Home</a></li>
          <li class="dropdown"><a href="about.html" class="active"><span>About</span></a></li>
          <li class="dropdown"><a href="events.php"><span>Events</span></a></li>
          <li class="dropdown"><a href="gallery.html"><span>Gallery</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <ul>
              <li><a href="gallery.html#photos">Photos</a></li>
              <li><a href="gallery.html#vid">Videos</a></li>
            </ul>
          </li>
          <li><a href="comments.php">Comments</a></li>
          <li><a href="donate.html">Donate</a></li>
          <li><a href="contact.html">Contact</a></li>
          <!-- <li><a href=""><i class="bi bi-person"></i></a></li> -->
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

    </div>
  </header>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title dark-background" style="background-image: url(assets/img/page-title-bg.jpg);">
      <div class="container position-relative">
        <h1>About</h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.html">Home</a></li>
            <li class="current">About</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- About Section -->
    <section id="About" class="about section">

      <div class="container">

        <div class="row position-relative">

          <div class="col-lg-7 about-img" data-aos="zoom-out" data-aos-delay="200"><br><br><img src="assets/img/logo.jpg"></div>

          <div class="col-lg-7" data-aos="fade-up" data-aos-delay="100">
            <h2 class="inner-title">About GivingTuesday</h2>
            <div class="our-story">
              <h3>GivingTuesday</h3>
              <p class="justified">GivingTuesday is the world’s largest generosity movement. Whether it is making someone smile, helping a stranger, or giving to those who need our help, every act of generosity counts, and everyone has something to give.</p>
              <ul>
                <li><i class="bi bi-check-circle"></i> <span><h3>Our Vision</h3></span></li>
                <h5>To inspire generosity</h5>
                <p>
                  Inspiring generosity can be a beautiful and impactful endeavor.
                </p>
                <li><i class="bi bi-check-circle"></i> <span></span><h3>Our Mission</h3></span></li>
                <h5>To develop an interconnected, passionate and mobilized network of givers, through meaningful partnerships, programmes and education, etc. </h5>
                <p class="justified">
                  Developing an interconnected, passionate, and mobilized network of givers involves several key strategies. Building meaningful partnerships is essential, as collaboration with like-minded organizations and individuals can amplify the impact of giving efforts. Implementing well-designed programs that address specific needs within the community can engage and inspire participants. Education plays a crucial role in this process, as informing people about the importance and benefits of giving can foster a culture of generosity. By combining these elements, you can create a vibrant network of givers who are motivated and equipped to make a significant difference.
                </p>
              </ul>
              <div class="watch-video d-flex align-items-center position-relative">
                <i class="bi bi-play-circle"></i>
                <a href="https://www.youtube.com/watch?v=EVogm8uttYw" class="glightbox stretched-link">Watch Video</a>
              </div>
            </div>
          </div>

        </div>

      </div>

    </section><!-- /About Section -->

    <!-- Team Section -->
    <section id="Team" class="team section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Our Amazing Team</h2>
        <p>At GivingTuesday Lesotho, our strength lies in our vibrant and passionate team, a diverse group of changemakers committed to fostering generosity and community spirit. Each member brings unique skills, passion, and a shared commitment to making a difference. From organizing events to developing innovative solutions. Meet the dedicated individuals behind our Mission, each playing a vital role in turning kindness into action !</p>
      </div><!-- End Section Title -->

      <div class="container">

        <div class="row gy-5">

          <div class="col-lg-4 col-md-6 member" data-aos="fade-up" data-aos-delay="100">
            <div class="member-img">
              <img src="assets/img/team/team-1.jpg" class="img-fluid" alt="">
              <div class="social">
                <a href="https://wa.me/26659030122"><i class="bi bi-whatsapp"></i></a>
                <a href="https://www.facebook.com/nolu.ndleleni.7"><i class="bi bi-facebook"></i></a>
                <a href="https://www.linkedin.com/in/limphomoteuli?utm_sources=share&utm_campaign=share_via&utm_content=profile&utm_medium=ios_app"><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
            <div class="member-info text-center">
              <span>Country Director</span>
              <h4>Mrs. Limpho Moteuli-Ndleleni</h4>
              <!-- <p>To be filled</p> -->
            </div>
          </div><!-- End Team Member -->

          <div class="col-lg-4 col-md-6 member" data-aos="fade-up" data-aos-delay="200">
            <div class="member-img">
              <img src="assets/img/team/team-2.jpg" class="img-fluid" alt="">
              <div class="social">
                <a href="https://wa.me/26658840163"><i class="bi bi-whatsapp"></i></a>
                <a href="https://www.facebook.com/sebuoeng.monoko?mibextid=ZbWKwL"><i class="bi bi-facebook"></i></a>
                <a href="https://www.instagram.com/matumelo.monoko/#"><i class="bi bi-instagram"></i></a>
                <a href="http://linkedin.com/in/matumelo-monoko-2b51153b"><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
            <div class="member-info text-center">              
              <span>Chief Operations Officer</span>
              <h4>Mrs. Matumelo Monoko</h4>
              <!-- <p>Labore ipsam sit consequatur exercitationem rerum laboriosam laudantium aut quod dolores exercitationem ut</p> -->
            </div>
          </div><!-- End Team Member -->

          <div class="col-lg-4 col-md-6 member" data-aos="fade-up" data-aos-delay="300">
            <div class="member-img">
              <img src="assets/img/team/team-4.jpg" class="img-fluid" alt="">
              <div class="social">
                <a href="https://wa.me/26657424799"><i class="bi bi-whatsapp"></i></a>
                <a href="https://www.facebook.com/gadaffi.cautiousmchini"><i class="bi bi-facebook"></i></a>
                <a href="https://www.instagram.com/gadafficautiousmchini?utm_source=qr&igsh=MmcwenZqcjM3M2pk"><i class="bi bi-instagram"></i></a>
                <a href="https://www.linkedin.com/in/sekantsikhotso"><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
            <div class="member-info text-center">
              <span>IT Specialist</span>
              <h4>Mr. Khotso Samuel Sekantsi</h4>
              
              <!-- <p>
                As a passionate software engineer, I am excited to join the GivingTuesdayLesotho crusade. My role involves developing and maintaining the crusade’s website, ensuring it effectively supports our mission. With a strong background in web development, I contribute to various technical aspects, enhancing our digital presence. I am dedicated to leveraging technology for social impact and committed to supporting the goals of GivingTuesdayLesotho. Together, we aim to foster a culture of generosity and community support in Lesotho.
              </p> -->
            </div>
          </div><!-- End Team Member -->
        </div>

      </div>

    </section><!-- /Team Section -->

    <!-- Partners Section -->
    <section id="Partners" class="testimonials section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Discover Our Partners</h2>
        <p>At GivingTuesday Lesotho, we believe in the power of collaboration to drive meaningful change. Our partners play a crucial role in amplifying our impact, bringing together resources, expertise, and passion to support our mission. By joining forces with us, our partners help to foster a culture of generosity and community spirit across Lesotho. Together, we can address pressing social issues, uplift vulnerable populations, and create a brighter future for all. We are grateful for the unwavering support and commitment of our partners, who share our vision of a more compassionate and resilient society. Therefore, the world's largest generosity movement, GivingTuesdayLesotho, has welcomed these incredible partners! Everybody can contribute, and kindness is appreciated in all its forms. If you want to be our partner in our crusade at GivingTuesdayLesotho, click <a href="partners.php">Here </a> to register as a partner.</p><br>
      </div><!-- End Section Title -->

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="swiper init-swiper">
          <script type="application/json" class="swiper-config">
            {
              "loop": true,
              "speed": 600,
              "autoplay": {
                "delay": 5000
              },
              "slidesPerView": "auto",
              "pagination": {
                "el": ".swiper-pagination",
                "type": "bullets",
                "clickable": true
              },
              "breakpoints": {
                "320": {
                  "slidesPerView": 1,
                  "spaceBetween": 40
                },
                "1200": {
                  "slidesPerView": 2,
                  "spaceBetween": 20
                }
              }
            }
          </script>
          <div class="swiper-wrapper">
            <?php
                // SQL query to select data
                $sql = "SELECT ORGANIZATION, Types, LOGO FROM partners";
                $result = mysqli_query($conn, $sql);
                $resultCheck = mysqli_num_rows($result);
                
                if($resultCheck > 0){
                  while($row = mysqli_fetch_array($result)){
                        echo '<div class="swiper-slide">';
                        echo '  <div class="testimonial-wrap">';
                        echo '    <div class="testimonial-item">';
                        echo '      <img src="assets/Organizations_Logos/' . $row["LOGO"] . '" class="testimonial-img" alt="">';
                        echo '      <h3>' . $row["ORGANIZATION"] . '</h3>';
                        echo '      <div class="stars">';
                        echo '        <i class="bi bi-star-fill" id="fst"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>';
                        echo '      </div>';
                        echo '      <p>';
                        echo '        <i class="bi bi-quote quote-icon-left"></i>';
                        echo '        <span>' . $row["Types"] . '</span>';
                        echo '        <i class="bi bi-quote quote-icon-right"></i>';
                        echo '      </p>';
                        echo '    </div>';
                        echo '  </div>';
                        echo '</div><!-- End testimonial item -->';
                    }
                } else {
                    echo "Partners will be displayed here after registration!";
                }
            ?>
          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>

    </section><!-- /Testimonials Section -->
    <!-- Team Section -->
    <section id="lead" class="team section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Our Amazing Community Leaders</h2>
        <p>
            Welcome to the Community Leaders section of GivingTuesday Lesotho, where we celebrate the inspiring individuals driving positive 
            change in their villages. These dedicated leaders embody the spirit of generosity and commitment, empowering their communities through service and support.
            Each leader plays a vital role in fostering collabration and inspiring others to contribute to local initiatives. Discover the faces behind these transformative efforts, and together we
            can build a brighter future for all. If you want to join our community leadership, click <a href="Leaders.php"> Here</a> to register and become a community leader.
        </p><br>
        <p>
          <span>
           <b><u>Who Can Lead a GivingTuesday Community:</u></b> We have a strong believe that the most effective way to address and solve local challenges or issues is through local leaders who understand the context.
            Anyone with a genuine passion for fostering positive change in their community can step up as a GivingTuesday Community Leader.
            It is essential for such individual to be prepared and willing to engage and collabrate with various stakeholders, including businesses, nonprofits and civil society,to drive that positive change together.
            To find out more about community leadership of GivingTuesday Lesotho - Be it the benefits of leading a GivingTuesday Community, What a community leader does and more - You can visit the Global GivingTuesday website by clicking <a href="https://www.givingtuesday.org/lead-givingtuesday-community-movement/">Here</a> .
          </span>
        </p>
      </div><!-- End Section Title -->

        <div class="row gy-5">

        <?php
            // SQL query to select data
            $sql = "SELECT fullnames, Village, District, Photo from leaders;";
            $result = mysqli_query($conn, $sql);
            $resultCheck = mysqli_num_rows($result);
            
            if($resultCheck > 0){
                while($row = mysqli_fetch_array($result)){
                echo '<div class="col-lg-4 col-md-6 member" data-aos="fade-up" data-aos-delay="100">';
                echo '    <div class="member-img">';
                echo '        <img src="assets/Leaders/' . $row["Photo"] . '" class="img-fluid" alt="">';
                echo '    </div>';
                echo '    <div class="member-info text-center">';
                echo '        <h4>' . $row["fullnames"] . '</h4>';
                echo '        <span>' . $row["Village"] . '</span>';
                echo '        <p>' . $row["District"] . '</p>';
                echo '    </div>';
                echo '</div><!-- End Leader Member -->';
                }
            } else {
                echo "Leaders will be displayed here after registration!";
            }
        ?>
        </div>

      </div>

    </section><!-- /Team Section -->
  </main>

  <footer id="footer" class="footer dark-background">

    <div class="container footer-top">
      <div class="row gy-4">
        <div class="col-lg-4 col-md-6 footer-about">
          <a href="index.html" class="logo d-flex align-items-center">
             <img src="assets/img/logo.png" alt="#GivingTuesday Lesotho" width="" height="400px">
          </a>
          <div class="footer-contact pt-3">
            <!-- <p>A108 Adam Street</p> -->
            <p>Matala, Phase 2, Maseru 100, Lesotho</p>
            <p class="mt-3"><strong>Phone:</strong><br> <span>(+266) 590 30 122 | 625 78 117</span></p>
            <p><strong>Email:</strong><br> <span>info@givingtuesdaylesotho.org.ls</span></p>
          </div>
          <div class="social-links d-flex mt-4">
            <!-- <a href=""><i class="bi bi-twitter-x"></i></a> -->
            <a href="https://www.facebook.com/profile.php?id=61564015867469"><i class="bi bi-facebook"></i></a>
            <a href="https://www.instagram.com/givingtuesdaylesotho?igsh=YzljYTk1ODg3Zg=="><i class="bi bi-instagram"></i></a>
            <a href="https://www.linkedin.com/company/giving-tuesday-lesotho/about/?viewAsMember=true"><i class="bi bi-linkedin"></i></a>
          </div>
        </div>

        <div class="col-lg-2 col-md-3 footer-links">
          <h4>Useful Links</h4>
          <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="donate.html">Donations</a></li>
            <li><a href="contact.html">Contact</a></li>
            <li><a href="privacy_policy.html">Privacy Policy</a></li>
            <!-- <li><a href="#">Terms of service</a></li> -->
          </ul>
        </div>
        
        <div class="col-lg-2 col-md-3 footer-links">
          <h4>About</h4>
          <ul>
            <li><a href="about.html#About">What is GivingTuesday ?</a></li>
            <li><a href="about.html#Team">Team members</a></li>
            <li><a href="about.html#Partners">Partners</a></li>            
            <li><a href="about.html#lead">Community Leaders</a></li>
          </ul>
        </div>

        <!-- <div class="col-lg-2 col-md-3 footer-links">
          <h4>Organizations</h4>
          <ul>
            <li><a href="Organizations.html#char">NGOs & Charities</a></li>
            <li><a href="Organizations.html#edu">Educational Facilities</a></li>
            <li><a href="Organizations.html#other">Other Institutions</a></li>
          </ul>
        </div> -->

        <div class="col-lg-2 col-md-3 footer-links">
          <h4>Gallery</h4>
          <ul>
            <li><a href="gallery.html#photos">Photo Gallery</a></li>
            <li><a href="gallery.html#vid">Video Gallery</a></li>
            <!-- <li><a href="#">Suscipit distinctio</a></li> -->
          </ul>
        </div>

      </div>
    </div>

    <div class="container copyright text-center mt-4">
      <p>© <span>Copyright</span> <strong class="px-1 sitename">GivingTuesday</strong> <span>All Rights Reserved</span></p>
      <div class="credits">
        Designed for: <a href="#">GivingTuesday Lesotho</a>
      </div>
    </div>

  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>