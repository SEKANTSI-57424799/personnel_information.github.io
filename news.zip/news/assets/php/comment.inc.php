<?php 
    if(isset($_POST['Add']))
    {
        $names = $_POST['names'];
        $email = $_POST['email'];
        $comment = $_POST['comment'];

        require 'dbcon.inc.php';
        # code...             
        $sql = "insert into comments (FULLNAMES, EMAILADDRESS, DETAILS) values ('".$names."','".$email."','".$comment."');";
        $result = mysqli_query($conn, $sql);
        if($result == 1)
        {
            echo "
                <script>alert ('Comment Successful !'); window.location.href='../../comments.php';</script>
            ";

        }
        else 
        {
            echo " Eroror : ".$conn -> error;
        }
}
    else
    {
        echo 'Failed to Comment !';
    }
?>