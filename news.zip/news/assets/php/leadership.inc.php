<?php 
    if(isset($_POST['Add']) && isset($_FILES['image'])){

        $id = $_POST['id'];
        $names = $_POST['names'];
        $email = $_POST['email'];
        $village = $_POST['village'];
        $district = $_POST['district'];
        $contacts = $_POST['contacts'];
        $age = $_POST['age'];

    require 'dbcon.inc.php';
    $img_name = $_FILES['image']['name'];
    $img_size = $_FILES['image']['size'];
    $temp_name = $_FILES['image']['tmp_name'];
    $error = $_FILES['image']['error'];

    if ($error === 0) 
	{
            # code...
            if ($img_size > 2250000) 
        	{
                echo "File size exceeds the Limit";
            }
        	else 
        	{
                $img_ext = pathinfo($img_name, PATHINFO_EXTENSION);
                $img_ext_lc = strtolower($img_ext);
    
                $allowed_exs = array('jpg', 'jpeg', 'png');
                if (in_array($img_ext_lc, $allowed_exs)) 
	           {
                    
                    $new_img_name =uniqid("IMG-", true).".".$img_ext_lc;
                    $img_upload_path = '../Leaders/'.$new_img_name;
                    move_uploaded_file($temp_name, $img_upload_path);
                    
                    $sql = "insert into Leaders (NationalID, fullnames, Emailaddress, Village, District, Contact, Age, Photo) values ('".$id."','".$names."','".$email."','".$village."','".$district."','".$contacts."','".$age."','".$new_img_name."');";
                    $results = mysqli_query($conn, $sql);
                    if($results > 0)
		            {
                        echo "
                            <script>alert ('Successfully Registered as a Community Leader !'); window.location.href='../../about.html';</script>
                        ";

                    }
                    else 
		            {
                        echo " Eroror : ".$conn -> error;
                    }
    
                }
        		else
        	   {
                    echo "Error Occured ";
               }
            }
    }
	else 
	{
         echo "Error Encountered "; 
    }
}
else
{
    echo 'Failed to Register !';
}
?>