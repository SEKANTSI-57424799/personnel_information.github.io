import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import java.sql.DriverManager;

public class DatabaseConnection 
{
    private final String URL = "jdbc:mysql://localhost:3306/ldf_library";
    private final String User = "root";
    private final String Password = "";
    private Statement stmt;
    private Connection con;
    private ResultSet rs;
    
    // a constructor of class DatabaseConnection
    public DatabaseConnection()
    {
        try
        {
            this.con = DriverManager.getConnection(this.URL,this.User,this.Password);
            this.stmt = this.con.createStatement();
        }
        catch(SQLException exception)
        {
             MessageBox(exception.toString(),"DATABASE CONNECTION", 0);
        }
    } 
    public static void MessageBox(String message,String heading, int panemessage)
    {
        JOptionPane.showMessageDialog(null, message,
               heading.toUpperCase(),panemessage);
    }
    //method for closing the entire connection
    public void CloseConnection()
    {
        try
        {
            this.stmt.close();
            this.con.close();
        }
        catch(SQLException exception)
        {
            MessageBox(exception.toString(),"DATABASE CONNECTION", 0);
        }
    }
    //method that will be used for all data definition language, 
    public void CreateDDL(String Query)
    {
        try
        {
            int result = stmt.executeUpdate(Query);
            if(result == 0)
            {
               MessageBox("QUERY SUCCESSFULLY CREATED","DDL QUERY", 1);
            }
            else 
                MessageBox("QUERY RESULTED IN AN ERROR","DDL QUERY",0);
            
        }catch(SQLException exception)
        {
            MessageBox("QUERY RESULTED IN AN ERROR:\n"+exception.toString() ,"DDL QUERY",0);
        }
        finally
        {
            this.CloseConnection();
        }
    }
    //method that will be used for Executing updates
    public void ExcecuteUpdate(String Query1)
    {
        try
        {
            int result = this.ExecuteStatement(Query1);
            if(result > 0)
            {
               MessageBox("QUERY SUCCESSFULLY CREATED"," QUERY EXCECUTION",1);
            }
            else
            {
                MessageBox("QUERY RESULTED IN AN ERROR","QUERY EXCECUTION", 0);
            }
        }
        catch(SQLException exception)
        {
            MessageBox("QUERY RESULTED IN AN ERROR:\n"+exception.toString(),"QUERY EXCECUTION",0);
        }
    }
    //method used for all statements executions
    public int ExecuteStatement(String query) throws SQLException
    {
        return this.stmt.executeUpdate(query);
    }
    //method used for records executions
    public ResultSet ExecuteRecords(String query) throws SQLException
    {
        return this.stmt.executeQuery(query);
    }
    // method used for getting all the records
    public ResultSet GetRecords(String sql)
    {
        try
        {
            this.rs = this.ExecuteRecords(sql);
        }
        catch(SQLException exception)
        {
             MessageBox("QUERY RESULTED IN AN ERROR","DDL QUERY",0);
        }
        return this.rs;
    }

}
