import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author KHOTSO SEKANTSI
 */
public class ALLFUNCTIONS {
    DatabaseConnection Db = new DatabaseConnection();
    
    public void REGISTEREMPLOYEE(String forceNo, String fullNames, String contacts, String unit, String Rank, String Officer )
            
    { 
         try
        {
            String Query = "INSERT INTO employee VALUES('"+ forceNo +"','"+ fullNames +"','"+ contacts +"','"+ unit+ "','"+Rank+"','"+Officer+"')";
            Db.ExcecuteUpdate(Query);
        }
         catch(Exception error)
        {
            Db.MessageBox(error.toString(),"Employee Registration!!!!!!!!!!!!",0);
        }
    }
    public void REGISTERBOOK(String ISBN,String RecordType,String Title, String SubTitle,String	Author,String Edition,String Price,String Place,String Publisher,String Subjects,String ClassificationNumber,String ISSN,String ShelfNumber,int NumberOfCopies,String AccessionNumber,String PublicationDate)
    { 
        try
        {
            String Query = "INSERT INTO book VALUES('"+ISBN+"','"+RecordType+"','"+Title+"','"+	SubTitle+"','"+	Author+"','"+Edition+"','"+Price+"','"+Place+"','"+Publisher+"','"+Subjects+"','"+ClassificationNumber+"','"+ISSN+"','"+	ShelfNumber+"','"+NumberOfCopies+"','"+	AccessionNumber+"','"+PublicationDate+"')";
            Db.ExcecuteUpdate(Query);
        }
        catch(Exception error)
        {
            Db.MessageBox(error.toString(),"BOOK REGISTRATION FAILED!!!!!!!!!!!!!!!!",0);
        }
    }   

    public void REGISTERISSUEBOOK(String ISBN, String ForceNumber, String IssueDate,String DueDate,String BookStatus)
    { 
        try
        {
            String Query = "INSERT INTO issuebook VALUES('"+ISBN+"','"+ForceNumber+"','"+IssueDate+"','"+DueDate+"','"+BookStatus+"')";
            Db.ExcecuteUpdate(Query);
        }
        catch(Exception error)
        {
            Db.MessageBox(error.toString(),"ISSUING FAILED!!!!!!!!!!!!!!!!",0);
        }
    } 
    public void STATISTICS(JTable table)
    {
        try
        {
            String query = "SELECT ISBN, ForceNumber, IssueDate, DueDate, BookStatus FROM ISSUEBOOK ";
            ResultSet Rs = Db.GetRecords(query);
            while(Rs.next())
            {
                String ISBN = Rs.getString(1);
                String ForceNumber = Rs.getString(2);
                String IssueDate = Rs.getString(3);
                String DueDate = Rs.getString(4);
                String BookStatus = Rs.getString(5);

                String[] tbldata = {ISBN, ForceNumber, IssueDate, DueDate, BookStatus};
                DefaultTableModel db = (DefaultTableModel)table.getModel();
                db.addRow(tbldata);
            }
        }
        catch(SQLException error)
        {
            Db.MessageBox(error.toString(),"DATABASE CONNECTION", 0);
        }
    }
    public void DeleteEmployee(String FORCE_NO)
    {
        try
        {
            String delete = "DELETE FROM employee WHERE ForceNumber = '"+ FORCE_NO +"' ";
            Db.ExcecuteUpdate(delete);
        }
        catch(Exception error)
        {
            Db.MessageBox(error.toString(), "DELETION", 0);
        }
    }
    public void DeleteIssueBook(String ISBN)
    {
        try
        {
            String delete = "DELETE FROM issuebook WHERE ISBN = '"+ ISBN +"' ";
            Db.ExcecuteUpdate(delete);
        }
        catch(Exception error)
        {
            Db.MessageBox(error.toString(), "DELETION OF ISSUE BOOK", 0);
        }
    }
}
